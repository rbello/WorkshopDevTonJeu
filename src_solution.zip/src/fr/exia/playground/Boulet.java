package fr.exia.playground;

import static java.lang.Math.pow;
import static java.lang.Math.tan;
import static java.lang.Math.toRadians;

import fr.exia.core.ElementQuiBouge;

public class Boulet extends ElementQuiBouge {
	
	public void compute(double t) {

		
		this.x =  initialVelocity * 
				Math.cos(Math.toRadians(initialAngle)) * t;
		
		this.y = (initialVelocity * 
				Math.sin(Math.toRadians(initialAngle)) * t) 
				- ((9.81* Math.pow(t,2)) / 2.0);
		
} 

}
