package fr.exia.playground;

import fr.exia.core.Fenetre;

public class Main {

	public static void main(String[] args) {
		
		Fenetre f = new Fenetre();

		Canon c = new Canon();
		c.x = 20;
		c.y = 620;
		
		Cible c1 = new Cible();
		c1.x = 400;
		c1.y = 450;
		
		Cible c2 = new Cible();
		c2.x = 900;
		c2.y = 200;
		
		c.charger(new Boulet());
		
		f.auClic((e) -> {
			System.out.println("Swag click t'as vu !");
			c.tirer(44, 98);
		});
		
		f.afficher();
		
	}
	
}
