package fr.exia.playground;

import fr.exia.core.ElementVisuel;

public class Cible extends ElementVisuel {

}
